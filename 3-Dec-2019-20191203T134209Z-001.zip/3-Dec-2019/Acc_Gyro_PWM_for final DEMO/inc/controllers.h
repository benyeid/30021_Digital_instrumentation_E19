#include "stm32f30x_conf.h"
#include "gpio.h"

int16_t balance_P();
int16_t balance_PID();
void balance_weight();
