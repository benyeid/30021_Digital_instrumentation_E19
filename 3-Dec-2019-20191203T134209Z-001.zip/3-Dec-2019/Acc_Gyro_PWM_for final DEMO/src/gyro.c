#include "gyro.h"

///--------------------------------------------------------GYRO FUNCTIONS---------------------------------------------------------///

uint8_t gyro_read(uint8_t address) ///modified function
{
    address |= 0x80;

    GPIOA->ODR &= ~(0x0001 << 4);
    while(SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) != SET) {  }
    SPI_I2S_SendData16(SPI3, address << 8);
    //while(SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) != SET) { }

    while(SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_RXNE) != SET) {  }
    uint8_t byte = 0xFF & SPI_I2S_ReceiveData16(SPI3);
    GPIOA->ODR |= (0x0001 << 4);

    return byte;
}

void gyro_send(uint8_t address, uint8_t data)
{
    uint16_t status = SPI_GetReceptionFIFOStatus(SPI3);
    address &= 0x7F;

    GPIOA->ODR &=~(0x0001 << 4);

    while(SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) != SET) {  }
    SPI_I2S_SendData16(SPI3, (address << 8)|data);
    //while(SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) != SET) { }

    while (SPI_GetReceptionFIFOStatus(SPI3) == status);
    SPI3->DR;

    GPIOA->ODR |= (0x0001 << 4);
}

void gyro_setup()
{
    GPIOA->ODR &= ~(0x0001 << 4);
    //gyro_send(GYRO_CTRL_REG4, 0x80);        ///BDU-1 (1: output registers not updated until MSB and LSB reading)
    //gyro_send(GYRO_CTRL_REG5, 0xC0);        ///Reboot memory content & FIFO enable
    gyro_send(GYRO_CTRL_REG2, 0x00);
    gyro_send(GYRO_CTRL_REG1, 0x0F);        ///Set power to normal mode and Enable x, y and z axis reading & Set Output Data Rate, Bandwidth
    GPIOA->ODR |=  (0x0001 << 4);
}

void gyro_temp()
{
    int8_t data = gyro_read(GYRO_OUT_TEMP);
    printf("temp: %d\n", data);
}

void gyro_status()
{
    int8_t data = gyro_read(GYRO_OUT_STAT);
    printf("status: %d\n", data);
}

void gyro_test()
{
    int8_t data = gyro_read(GYRO_WHOAMI);
    printf("Gyro ID: %x ||\n", data);
}

void gyro_getValues()
{
    int16_t x, y, z = 0;
    x = (gyro_read(GYRO_OUT_X_H)<<8) | gyro_read(GYRO_OUT_X_L);
    y = (gyro_read(GYRO_OUT_Y_H)<<8) | gyro_read(GYRO_OUT_Y_L);
    z = (gyro_read(GYRO_OUT_Z_H)<<8) | gyro_read(GYRO_OUT_Z_L);
    printf("Gyro || x : y : z ||  %d  :  %d  :  %d  \n", x, y-150, z);
}

void init_spi3() {
    // Enable Clocks
    RCC->APB1ENR |= RCC_APB1Periph_SPI3;
    initPinAlternate(GPIOB, 3, 6);
    initPinAlternate(GPIOB, 4, 6);
    initPinAlternate(GPIOB, 5, 6);


    initPin(GPIOA, 4, PIN_MODE_OUTPUT, PIN_PUPD_NONE, PIN_OTYPE_RESET);

    // Configure SPI3
    SPI3->CR1 &= 0x3040; // Clear CR1 Register
    SPI3->CR1 |= 0x0000; // Configure direction (0x0000 - 2 Lines Full Duplex, 0x0400 - 2 Lines RX Only, 0x8000 - 1 Line RX, 0xC000 - 1 Line TX)
    SPI3->CR1 |= 0x0104; // Configure mode (0x0000 - Slave, 0x0104 - Master)
    SPI3->CR1 |= 0x0002; // Configure clock polarity (0x0000 - Low, 0x0002 - High)
    SPI3->CR1 |= 0x0001; // Configure clock phase (0x0000 - 1 Edge, 0x0001 - 2 Edge)
    SPI3->CR1 |= 0x0200; // Configure chip select (0x0000 - Hardware based, 0x0200 - Software based)
    SPI3->CR1 |= 0x0008; // Set Baud Rate Prescaler (0x0000 - 2, 0x0008 - 4, 0x0018 - 8, 0x0020 - 16, 0x0028 - 32, 0x0028 - 64, 0x0030 - 128, 0x0038 - 128)
    SPI3->CR1 |= 0x0000; // Set Bit Order (0x0000 - MSB First, 0x0080 - LSB First)
    SPI3->CR2 &= ~0x0F00; // Clear CR2 Register
    SPI3->CR2 |= 0x0F00; // Set Number of Bits (0x0300 - 4, 0x0400 - 5, 0x0500 - 6, ...);
    SPI3->I2SCFGR &= ~0x0800; // Disable I2S
    SPI3->CRCPR = 7; // Set CRC polynomial order
    SPI3->CR2 &= ~0x1000;
    SPI3->CR2 |= 0x1000; // Configure RXFIFO return at (0x0000 - Half-full (16 bits), 0x1000 - Quarter-full (8 bits))
    SPI3->CR1 |= 0x0040; // Enable SPI3

    //for (uint32_t i = 0 ; i < 5000000 ; i++) { __asm__("nop"); }; // Wait
    GPIOA->ODR |=  (0x0001 << 4);
}
